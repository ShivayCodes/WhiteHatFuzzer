# 🛡️ WhiteHatFuzzer

**WhiteHatFuzzer** is an advanced Python + JavaScript web fuzzing tool built for ethical hackers. It discovers hidden directories, parameters, inputs, files, and misconfigurations using various fuzzing techniques.

## 🔍 Features

- Built for ethical testing
- JavaScript frontend + Python backend
- Fuzzing modes:
  - Web path discovery
  - Parameter fuzzing
  - Header fuzzing
  - JSON payloads
  - File upload fuzzing
  - GraphQL fuzzing
- Input and output saving to JSON files
- No root access needed

## ▶️ Getting Started

```bash
pip install flask requests
python3 app.py
```

Visit `http://localhost:5000`

## 📁 Output

Results are stored in the `data/` directory in JSON format.

## ⚠️ Ethical Use Only

Use responsibly and only with permission.

## 📜 License

MIT License