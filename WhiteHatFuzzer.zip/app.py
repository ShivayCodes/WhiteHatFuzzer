from flask import Flask, render_template, request, jsonify, send_file
import subprocess
import json
import uuid

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run', methods=['POST'])
def run_fuzz():
    data = request.json
    task_id = str(uuid.uuid4())
    target = data['target']
    wordlist = data['wordlist']
    mode = data['mode']
    output_file = f"data/{task_id}.json"

    with open(output_file, "w") as f:
        subprocess.run(['python3', 'fuzzer.py', target, wordlist, mode, output_file], stdout=subprocess.DEVNULL)

    with open(output_file) as f:
        results = json.load(f)
    return jsonify({"task_id": task_id, "results": results})

@app.route('/download/<task_id>')
def download(task_id):
    return send_file(f"data/{task_id}.json", as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)