import requests, sys, json

target = sys.argv[1]
wordlist = sys.argv[2]
mode = sys.argv[3]
output_file = sys.argv[4]

with open(wordlist) as f:
    payloads = f.read().splitlines()

results = []

for payload in payloads:
    try:
        if mode == "web":
            url = f"{target.rstrip('/')}/{payload}"
            r = requests.get(url, timeout=3)
            results.append({"url": url, "status": r.status_code})
        elif mode == "param":
            url = f"{target}?{payload}=fuzz"
            r = requests.get(url, timeout=3)
            results.append({"url": url, "status": r.status_code})
        elif mode == "header":
            r = requests.get(target, headers={payload: "fuzz"}, timeout=3)
            results.append({"header": payload, "status": r.status_code})
        elif mode == "json":
            r = requests.post(target, json={payload: "fuzz"}, timeout=3)
            results.append({"json": payload, "status": r.status_code})
        elif mode == "graphql":
            r = requests.post(target, json={"query": payload}, timeout=3)
            results.append({"graphql": payload, "status": r.status_code})
    except Exception as e:
        continue

with open(output_file, "w") as f:
    json.dump(results, f, indent=2)