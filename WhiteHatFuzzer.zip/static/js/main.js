document.getElementById('fuzzForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const target = document.getElementById('target').value;
    const wordlist = document.getElementById('wordlist').value;
    const mode = document.getElementById('mode').value;

    document.getElementById('output').innerText = 'Running fuzzing...';

    fetch('/run', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ target, wordlist, mode })
    })
    .then(res => res.json())
    .then(data => {
        let out = '';
        data.results.forEach(r => {
            out += JSON.stringify(r) + "\n";
        });
        document.getElementById('output').innerText = out;
        const link = document.createElement("a");
        link.href = `/download/${data.task_id}`;
        link.innerText = "📥 Download Results";
        document.body.appendChild(link);
    });
});